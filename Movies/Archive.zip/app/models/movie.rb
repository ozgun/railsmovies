class Movie < ActiveRecord::Base
end
